# Ahmedabad Automatic Steel Monitor

## Start (Windows)
Install Python 3.10+, open a terminal in this folder:

```
py -m pip install -r requirements.txt
py app.py
```

Open http://localhost:5000 . Data fetching starts automatically and repeats every 24 hours while the process runs. The browser refreshes its dashboard every 5 minutes. CSV export is available. Database is stored in steel_prices.sqlite3.

## Important limitations

- **Not deployed:** Your PC must remain on and the process running. For unattended updates, deploy to an always-on Python host with persistent disk, and start `python app.py` as the service command. A host that sleeps or wipes its disk will not provide reliable history.
- No guaranteed free API for all six product categories was found. The collectors parse public HTML tables from easeInfra Ahmedabad and Ayron Mart. If a page's structure changes, an item is unavailable rather than made up. The scraper does not bypass access restrictions.
- ISMC is only recognized when explicitly marked ISMC; otherwise channel is shown as C Channel. ISMB uses MS Beam as a market proxy; MS Sheet may use sheet/plate/HR coil as a proxy, so always inspect grade/specification. Pipe requires a dated Ahmedabad source listing.
- Source quote date is displayed; the fetch date is separate. Prices are benchmarks, not supplier offers. Confirm taxes, size, grade, quantity and freight before buying.
- The app has no public write endpoint. Add authentication, HTTPS, monitoring and an authorized data-feed contract before production deployment.
- To run via production WSGI, move scheduler into a dedicated process; the built-in scheduler runs only with `python app.py`.
