import os,re,sqlite3,threading,time,datetime,csv,io
from flask import Flask,jsonify,render_template_string,Response
import requests
from bs4 import BeautifulSoup
from zoneinfo import ZoneInfo

app=Flask(__name__)
DB=os.environ.get('STEEL_DB','steel_prices.sqlite3')
TZ=ZoneInfo('Asia/Kolkata')
SOURCE='https://www.easeinfra.com/live-steel-prices-in-ahmedabad'
SECOND='https://ayronmart.com/angle-channel-pipe-structure-prices/'
MATERIALS=['C Channel','MS Sheet','Angle','ISMB','ISMC','Pipe']
lock=threading.Lock()
def now(): return datetime.datetime.now(TZ).isoformat(timespec='seconds')
def conn():
 c=sqlite3.connect(DB,timeout=30);c.row_factory=sqlite3.Row;return c
def init():
 with conn() as c:
  c.execute('CREATE TABLE IF NOT EXISTS prices (id INTEGER PRIMARY KEY, material TEXT NOT NULL, specification TEXT NOT NULL, rate REAL NOT NULL, quoted_at TEXT NOT NULL, observed_at TEXT NOT NULL, source TEXT NOT NULL, UNIQUE(material,specification,quoted_at,source))')
  c.execute('CREATE TABLE IF NOT EXISTS runs (id INTEGER PRIMARY KEY, checked_at TEXT, status TEXT, message TEXT, count INTEGER)')
def parse_ease(html):
 soup=BeautifulSoup(html,'html.parser'); rows=[]
 for tr in soup.select('tr'):
  cells=[x.get_text(' ',strip=True) for x in tr.find_all(['td','th'])]
  if len(cells)<4:continue
  product=cells[0].lower(); spec=cells[2] if len(cells)>2 else ''
  if 'channel' in product: material='ISMC' if re.search(r'\bISMC\b',spec,re.I) else 'C Channel'
  elif 'beam' in product: material='ISMB'
  elif 'angle' in product: material='Angle'
  elif 'sheet' in product or 'plate' in product or 'hr coil' in product:material='MS Sheet'
  elif 'pipe' in product:material='Pipe'
  else:continue
  if 'ahmedabad' not in ' '.join(cells).lower():continue
  match=re.search(r'₹\s*([\d,]+(?:\.\d+)?)\s*/\s*(MT|KG)',cells[3],re.I)
  if not match:continue
  rate=float(match.group(1).replace(',',''))/(1000 if match.group(2).upper()=='MT' else 1)
  if not 10<=rate<=500:continue
  date=''
  for cell in cells[4:]:
   m=re.search(r'(\d{1,2})\s+([A-Za-z]{3,9})\s+(20\d{2})',cell)
   if m:
    try:date=datetime.datetime.strptime(' '.join(m.groups()),'%d %b %Y').date().isoformat()
    except ValueError:
     try:date=datetime.datetime.strptime(' '.join(m.groups()),'%d %B %Y').date().isoformat()
     except ValueError:pass
    break
  if not date:continue # do not stamp old prices as current
  rows.append((material,spec or product,rate,date,SOURCE))
 return rows

def parse_ayron(html):
 soup=BeautifulSoup(html,'html.parser');out=[]
 for tr in soup.select('tr'):
  cells=[x.get_text(' ',strip=True) for x in tr.find_all(['td','th'])]
  if len(cells)<5 or cells[0].lower()!='ahmedabad':continue
  mat={'angle':'Angle','channel':'C Channel','pipe':'Pipe'}.get(cells[2].lower())
  if not mat:continue
  p=re.search(r'([\d,]+)',cells[3]);d=re.search(r'(\d{1,2})[- ]([A-Za-z]+)[- ](20\d{2})',cells[4])
  if not p or not d:continue
  try:day=datetime.datetime.strptime(' '.join(d.groups()),'%d %B %Y').date().isoformat()
  except ValueError:continue
  rate=float(p.group(1).replace(',',''))/1000
  if 10<=rate<=500:out.append((mat,'Market benchmark (size unspecified)',rate,day,SECOND))
 return out

def fetch():
 if not lock.acquire(blocking=False):return {'status':'busy','count':0}
 try:
  items=[];errors=[]
  for url,parser in [(SOURCE,parse_ease),(SECOND,parse_ayron)]:
   try:
    r=requests.get(url,timeout=18,headers={'User-Agent':'Mozilla/5.0 (compatible; SteelMonitor/1.0)'})
    r.raise_for_status(); parsed=parser(r.text)
    if not parsed:errors.append(url+': no parsable dated rows')
    items.extend(parsed)
   except Exception as e:errors.append(url+': '+str(e)[:180])
  with conn() as c:
   for m,s,p,d,u in items:
    c.execute('INSERT OR IGNORE INTO prices(material,specification,rate,quoted_at,observed_at,source) VALUES(?,?,?,?,?,?)',(m,s,p,d,now(),u))
   status='ok' if items else 'unavailable'
   c.execute('INSERT INTO runs(checked_at,status,message,count) VALUES(?,?,?,?)',(now(),status,'; '.join(errors)[:900],len(items)))
  return {'status':status,'count':len(items),'errors':errors}
 finally:lock.release()

def scheduler():
 while True:
  try:fetch()
  except Exception as e:
   with conn() as c:c.execute('INSERT INTO runs(checked_at,status,message,count) VALUES(?,?,?,?)',(now(),'error',str(e)[:400],0))
  time.sleep(24*3600)

@app.get('/api/prices')
def prices():
 with conn() as c:
  records=[dict(r) for r in c.execute('SELECT * FROM prices ORDER BY quoted_at DESC,id DESC')]
  last=c.execute('SELECT * FROM runs ORDER BY id DESC LIMIT 1').fetchone()
 result=[]
 for m in MATERIALS:
  group=[r for r in records if r['material']==m]
  unique={}
  for r in group:unique.setdefault((r['specification'],r['source']),r)
  result.append({'material':m,'quotes':list(unique.values()),'history':group[:120]})
 return jsonify({'materials':result,'last_run':dict(last) if last else None,'server_time':now()})
@app.get('/api/export.csv')
def export():
 with conn() as c: rows=c.execute('SELECT material,specification,rate,quoted_at,observed_at,source FROM prices ORDER BY quoted_at DESC').fetchall()
 buf=io.StringIO();w=csv.writer(buf);w.writerow(['Material','Specification','INR/kg','Source quote date','Fetched at','Source URL']);w.writerows([tuple(x) for x in rows]);return Response(buf.getvalue(),mimetype='text/csv',headers={'Content-Disposition':'attachment; filename=steel_history.csv'})
@app.get('/')
def home():return render_template_string(HTML)
HTML='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Ahmedabad Steel Monitor</title><style>body{font:15px system-ui;background:#f3f6fb;color:#16243b;margin:0}header{background:#142b4d;color:white;padding:26px max(20px,calc((100vw - 1100px)/2))}main{max-width:1100px;margin:24px auto;padding:0 16px}h1{margin:0 0 8px}p{line-height:1.6}.muted{color:#617189}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:14px}.card{background:white;border:1px solid #dde5f0;border-radius:14px;padding:20px;box-shadow:0 3px 14px #1b35500a}.rate{font-size:30px;font-weight:750;margin:10px 0}.small{font-size:12px;color:#617189}.pill{display:inline-block;background:#edf3fa;border-radius:99px;padding:5px 10px;font-size:12px}a{color:#1765ba}button,.btn{border:0;background:#1870cc;color:white;border-radius:8px;padding:11px 16px;cursor:pointer;text-decoration:none;display:inline-block}button:disabled{opacity:.6}.toolbar{display:flex;gap:10px;flex-wrap:wrap;margin:18px 0}select{padding:10px;border:1px solid #d5dfeb;border-radius:8px}table{border-collapse:collapse;width:100%;font-size:13px}td,th{padding:10px;border-bottom:1px solid #e8edf4;text-align:left}th{background:#f5f8fc}.warn{background:#fff4d6;padding:12px;border-radius:8px}.up{color:#b42318}.down{color:#16734b}</style><header><h1>Ahmedabad Steel Price Monitor</h1><div>Automated public-source monitoring · Rates in ₹/kg · India Standard Time</div></header><main><div class="warn"><b>Source quotes, not guaranteed live prices.</b> Dates are from publisher listings; missing materials stay unavailable. Prices may exclude GST, freight and supplier margins.</div><div class="toolbar"><button onclick="load()">↻ Refresh dashboard</button><a class="btn" href="/api/export.csv">Export CSV</a><select id="filter" onchange="render()"><option value="all">All materials</option><option>C Channel</option><option>MS Sheet</option><option>Angle</option><option>ISMB</option><option>ISMC</option><option>Pipe</option></select></div><p id="status" class="muted">Loading…</p><div id="cards" class="cards"></div><h2>Source details</h2><p>Data collection is automatic while the backend runs. No manual price entry is needed. Source sites can change their HTML or block scraping; the app reports missing data rather than inventing rates.</p><p><a href="https://www.easeinfra.com/live-steel-prices-in-ahmedabad" target="_blank" rel="noopener">easeInfra Ahmedabad</a> · <a href="https://ayronmart.com/angle-channel-pipe-structure-prices/" target="_blank" rel="noopener">Ayron Mart</a></p></main><script>let data=null;const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));async function load(){try{const r=await fetch('/api/prices');if(!r.ok)throw Error(r.status);data=await r.json();render()}catch(e){document.getElementById('status').textContent='Server connection failed: '+e.message}}function render(){if(!data)return;const run=data.last_run;document.getElementById('status').textContent='Last automatic check: '+(run?.checked_at||'Not yet checked')+' · '+(run?.status||'pending')+' · '+(run?.count||0)+' source rows';const f=document.getElementById('filter').value;document.getElementById('cards').innerHTML=data.materials.filter(x=>f==='all'||x.material===f).map(x=>'<article class="card"><h2>'+esc(x.material)+'</h2>'+(x.quotes.length?x.quotes.map(q=>'<div style="border-top:1px solid #eee;padding:10px 0"><div class="rate">₹'+Number(q.rate).toFixed(2)+'/kg</div><div>'+esc(q.specification)+'</div><div class="small">Quoted: '+esc(q.quoted_at)+' · <a href="'+encodeURI(q.source)+'" target="_blank" rel="noopener">Source</a></div></div>').join(''):'<p class="muted">No verified source quote available</p>')+'</article>').join('')}load();setInterval(load,300000)</script></html>'''
if __name__=='__main__':
 init();threading.Thread(target=scheduler,daemon=True).start();app.run(host='0.0.0.0',port=int(os.environ.get('PORT','5000')),debug=False)
